
namespace dotnetapp.Models
{
  public class Actor
  {
        public string Name { get; set; }
        public int Age { get; set; }
        public List<Movie> Movies { get; set; }
  }
}
