
namespace dotnetapp.Models
{
  public class Movie
  {
        public string Title { get; set; }
        public DateTime ReleaseDate { get; set; }
        public double Rating { get; set; }
  }
}
