﻿using System;
using System.Collections.Generic;

namespace CenterBookingSystem.Models
{
    // write your Booking class here...
}
