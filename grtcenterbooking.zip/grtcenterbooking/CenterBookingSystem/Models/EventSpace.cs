﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CenterBookingSystem.Models
{
        // write your EventSpace class here...
}
