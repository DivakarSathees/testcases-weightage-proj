﻿using System;

namespace CenterBookingSystem.Models
{
        // write your EventBookingException class here...
}