﻿using CenterBookingSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace CenterBookingSystem.Data
{
    public class BookingDbContext : DbContext
    {
        // Write your BookingDbContext here...
    }

}
