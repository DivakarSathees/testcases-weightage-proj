﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using CenterBookingSystem.Models;
using CenterBookingSystem.Data;

namespace CenterBookingSystem.Controllers
{
    public class EventSpaceController : Controller
    {        
        // Write your EventSpaceController here...
        // AvailableSpaces() - returns View(availableSpaces)
        //                   - Display available event spaces
    }
}
