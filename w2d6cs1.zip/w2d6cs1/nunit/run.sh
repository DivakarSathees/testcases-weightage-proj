#!/bin/bash
if [ -d "/home/coder/project/workspace/dotnetapp/" ]
then
    echo "project folder present"
    # checking for src folder
    if [ -d "/home/coder/project/workspace/dotnetapp/" ]
    then
        cp -r /home/coder/project/workspace/nunit/test/TestProject /home/coder/project/workspace/;
        cp -r /home/coder/project/workspace/nunit/test/dotnetapp.sln /home/coder/project/workspace/dotnetapp/;
    cd /home/coder/project/workspace/dotnetapp || exit;
     dotnet clean;    
     dotnet test;
    else
        echo "Testing_CreateBook_AddsBookToDatabase FAILED";
        echo "Test_Book_Class_Exists FAILED";
        echo "Test_Book_Id_Property_DataType FAILED";
        echo "Test_Book_Title_Property_DataType FAILED";
        echo "Test_Dept_Price_Property_DataType_Decimal FAILED";
        echo "BookDbContextContainsDbSetBooks_Property FAILED";
    fi
else   
    echo "Testing_CreateBook_AddsBookToDatabase FAILED";
    echo "Test_Book_Class_Exists FAILED";
    echo "Test_Book_Id_Property_DataType FAILED";
    echo "Test_Book_Title_Property_DataType FAILED";
    echo "Test_Dept_Price_Property_DataType_Decimal FAILED";
    echo "BookDbContextContainsDbSetBooks_Property FAILED";
fi